
## 2.6.3 / 2014-06-19
==================

 * Fixes to grunt tasks
 * Remove jQuery post install
 * Merge branch 'update-travis-tests' into adds-grunt-tasks
 * update paths
 * fix plugin path for tests
 * Change bootstrap
 * Use the new develop WordPress repo for testing
 * Fix stupid mistake
 * Try HTTPS for submodule
 * Needs a separator
 * Move hm-backup
 * Add deploy task
 * Add some more automation
 * Remove some unused tasks
 * require hm-backup
 * Add hm backup as submodule again
 * Remove composer module hm-backup
 * update path for tests
 * Readme parts
 * Readme footer part
 * Add more grunt tasks
 * FAQ strings
 * adds css minify plugin
 * add plugin header
 * Adds uglify and JS Hint tasks
 * Minified JS
 * Enqueue the minified version
 * add JS hint rules
 * Add readme task and generate
 * move plugin files to src subdir
 * Adds composer.json
 * Adds bower.json
 * Ignore query installed by bower
 * Custom install folder for bower
 * Create POT file task
 * No more submodules
 * remove hm backup submodule
 * remove colorbox submodule
 * Ignore node modules
 * Adds package.json
 * Merge pull request #445 from elliott-stocks/enhancement-heartbeat
 * Small typo in readme
 * Add redirect to heartbeat tick
 * Remove unnecessary code, add heartbeat functionality
 * Remove hmbkpRedirectOnBackupComplete
 * Enqueue heartbeat API
 * Allow output to be returned for AJAX requests
 * Add heartbeat received filter
