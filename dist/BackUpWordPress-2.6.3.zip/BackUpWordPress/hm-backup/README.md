hm-backup
=========

The core backup engine that powers BackUpWordPress &amp; WP Remote

## Contribution guidelines ##

see https://github.com/humanmade/hm-backup/blob/master/CONTRIBUTING.md
